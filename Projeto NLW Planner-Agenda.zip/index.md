HTML 
- Hypertext
  > texto clicável
- Markup 
  > tags (<), elementos
- Language
  > sintaxe


  a+enter >>> <a href(atributo link)="https://google.com">google.com</a>


div = caixa 
input = tag fecha
span = elemento do lado do outro
div = pode usar p/abaixo

CSS
- Cascading Style Sheet
- ordens p/html 
hi {
  color: rgb(255, 112, 136);
  text-decoration: underline;
}

DARKMODE> html {
  background-color: #09090B;
  color: #f4f4f5; 
}


JAVASCRIPT
- Intepretada pelo browser
- Dinâmica
- Orientado a objeto
- ECMAScript trazendo inovações

Fases da resolução de um problema:
1- coletar os dados; 
2- processar os dados;
3- apresentar os dados/armazenar;

const cria variavel constante, n vai mudar nunca (ate o final do programa);
let pode mudar as informações; 

length = quantos elementos tem na lista
onsubmit = enviar botão ao clicar





